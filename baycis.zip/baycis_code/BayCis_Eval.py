import sys, os
from ConfigParser import ConfigParser, NoOptionError
from scipy.io import read_array, numpyio
from scipy import dtype, fromfile
import hmm as m_hmm
from biotools import evaluate_motifs
import fasta, mtf
from itertools import count

params = sys.argv[1]

config = ConfigParser()
config.read([params])
config_name = config.get("DEFAULT", "config_name")

#############
# load motifs

mtf_dir = config.get("DEFAULT", "mtf_dir")
num_mtfs = config.getint("Motifs", "num_mtfs")
mtfs = []
for i in range(num_mtfs):
    tmp = eval(config.get("Motifs", str(i)))
    fname = "%s/%s" % (mtf_dir, tmp[1])
    m = mtf.load_ACGT( tmp[0], fname )
    m.init_prob()
    mtfs.append( m )

mtf_types = set([])
for m in mtfs:
    mtf_types.add(m.name)

####################################
# load sequences and add them to HMM
seqs = []
num_seq = config.getint("Sequences", "num_seq")
seq_dir = config.get("DEFAULT", "seq_dir")
for i in range(num_seq):
    seq_name = config.get("Sequences", str(i))
    seq_fname = os.path.join(seq_dir, seq_name)
    seq = fasta.load_fasta( seq_fname )
    # load annotation
    anno_name = config.get("Annotation", str(i))
    anno_fname = os.path.join(seq_dir, anno_name)
    anno = fasta.load_common_annotation( anno_fname  )
    seq.update_attributes(anno)
    seqs.append( seq )
    
################################################
# load hmm
#
# hmm is a dictionary
#  -  key represents starting state of a motif
#     in an hmm
#  -  value represents name of a motif

h = m_hmm.load(config.get("Eval", "hmm"))
hmm = {}
for i, m in zip(count(), mtfs):
    hmm[h['start_motifs']+i] = m.name
    hmm[h['start_motifs']+i+h['nmtfs']] = m.name

precision = []
recall = []
tp, fp, tot_mtf = 0, 0, 0

for it in range(num_seq):
    #######################
    # load posterior matrix

    f = open(config.get("Eval", "params", vars={'config_name': '%s_seq_%d' % (config_name, it)}))
    datatype = eval(f.next())
    size = eval(f.next())
    shape = eval(f.next())
    f = open(config.get("Eval", "post", vars={'config_name': '%s_seq_%d' % (config_name, it)}))
    post = fromfile(file=f, dtype=datatype, count=size)
    post = post.reshape(shape)
    
    post = post.argmax(1)               # maximum over columns 

    seq_mtfs = []

    for i, v in zip(count(), post):
        try:
            seq_mtfs.append((hmm[v], i))
        except:
            pass
    
    eval_pos, eval_type = [], []
    for t,m in seq_mtfs:
        m = int(m)
        flag = False
        for min,max in seq.crm_border:
            if m >= min and m <= max:
                flag = True
                
        if flag:
            eval_pos.append(m)
            eval_type.append(t)

    true_pos, true_type = [], []
    for t,p in zip(seqs[it].mtf_type, seqs[it].mtf_position):
        if t not in mtf_types: continue
        true_pos.append(p)
        true_type.append(t)

    # true_positive, false_positive, total_number_motif
    tmp = evaluate_motifs(zip(eval_type, eval_pos),
                          zip(true_type, true_pos),
                          dist=1)

    tp += tmp[0]
    fp += tmp[1]
    tot_mtf += tmp[2]
    
if not (tp+fp):
    precision.append(0.)
else:
    precision.append(1.*tp/(tp+fp))
recall.append(1.*tp/tot_mtf)

open(config.get("Eval", "eval"), 'w').write("%f %f\n" % (precision[0], recall[0]))
print precision[0], recall[0]
