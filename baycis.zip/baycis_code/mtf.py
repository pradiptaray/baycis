"""
>>> from mtf import Mtf
>>> m = Mtf("hb", [[2, 3, 4], [3, 1, 5], [0, 7, 1], [1, 7, 2]])
>>> m.site_freq(0)
[2, 3, 0, 1]
>>> m.site_freq_back_strand(0)
[2, 1, 5, 4]

"""


from scipy import array, random, zeros
from itertools import count

class Mtf(object):
    nucl2num = ['A', 'C', 'G', 'T']
    def __init__(self, name, freq):
        self.name = name
        self.freq = freq
        self.len = len(freq[0])
        self.p = zeros((4, self.len))
        self.bp = zeros((4, self.len))
            
    #frequency
    def site_freq(self, site):
        ret = []
        for nuc in range(4):
            ret.append(self.freq[nuc][site])        
        return ret
    def site_freq_back_strand(self, site):
        ret = self.site_freq(self.len-1-site)
        return [ret[3], ret[2], ret[1], ret[0]]
    ##

    # probability
    def init_prob(self, smooth=0.001):
        for i in range(self.len):
            t = array(self.site_freq(i), dtype=float) + smooth
            self.p[:, i] = t / t.sum()
            t = array(self.site_freq_back_strand(i), dtype=float) + smooth
            self.bp[:, i] = t / t.sum()
    def site_prob(self, site, nucl, strand=0):
        if not strand:
            return self.p[Mtf.nucl2num.index(nucl), site]
        else:
            return self.bp[Mtf.nucl2num.index(nucl), site]
    ##    
    def generate(self, strand=0):
        ret = ''
        if strand:
            p = self.bp
        else:
            p = self.p
        for i in range(self.len):
            ret += self.nucl2num[random.multinomial(1, p[:, i]).argmax()]
        return ret
    ##
    def write(self, f):
        for i in range(self.len):
            f.write('%s\n' % " ".join(map(str, self.site_freq(i))))
    ##
    def evaluate_sequence(self, seq, strand=0):
        from scipy import prod
        if len(seq) != self.len:
            raise Exception, "Sequence must be as long as motif"
        return prod([self.site_prob(i,n,strand) for i, n in zip(count(), seq)])


def load(name, f):
    """
    Loads a motif from a file that has a line for each site in a motif. Each line
    represents counts of a nucleotides A, C, G, T in that order.
    """
    import re
    try:
        f + ""
        f = open(f, 'r')
    except TypeError:
        pass
    freq = [[],[],[],[]]
    for line in f.readlines():
        if not line.strip(): continue
        for i,v in zip(count(), map(int, re.split(r"\s+", line.strip()))):
            freq[i].append(v)
    return Mtf(name, freq)

def load_ACGT(name, f):
    """
    Loads a motif from a file that has four lines, each line represents counts
    of a nucleotide at different sites of a motif. Lines represent nucleotides
    A, C, G, T in that order.
    """
    import re
    try:
        f + ""
        f = open(f, 'r')
    except TypeError:
        pass

    freq = [map(int, re.split(r"\s+", line.strip())) for line in f.readlines()[:4]]
    return Mtf(name, freq)

def save_cister(mtfs, f):
    """
    mtfs - list of motif instances
    """
    for m in mtfs:
        f.write('>%s\n' % m.name)
        f.write('1 1\n')        
        for i in range(m.len):
            f.write('%s\n' % " ".join(map(str, m.site_freq(i))))           

def save_phylogibbs(mtfs, f):
    """
    :Phylogibbs format:
    
    NA  name_1
    01      1      2      2      0      
    02      2      1      2      0      
    03      3      0      1      1      
    04      0      5      0      0      
    05      5      0      0      0      
    06      0      0      4      1      
    07      0      1      4      0      
    08      0      0      0      5      
    09      0      0      5      0      
    10      0      1      2      2      
    11      0      2      0      3      
    12      1      0      3      1      
    //
    NA name_2
    01      2      1      2      0      
    02      1      2      2      0      
    03      0      5      0      0      
    04      3      0      1      1      
    05      0      0      4      1      
    06      5      0      0      0      
    07      0      1      4      0      
    08      0      0      5      0      
    09      0      0      0      5      
    10      0      2      0      3      
    11      0      1      2      2      
    12      1      0      3      1      
    //    
    """

    for m in mtfs:
        f.write("NA %s\n" % m.name)
        for i in range(m.len):
            f.write("%02d\t%s\n" % ((i+1), "\t".join( map(str, m.site_freq(i)) )))
        f.write("//\n")
