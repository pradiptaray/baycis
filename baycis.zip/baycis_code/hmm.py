from scipy import zeros, exp, log, tile, dot, allclose
from scipy.special import psi
from itertools import count
from models import BcgModel
from time import time

class HMM(object):
    def __init__(self, mtfs, priors, params):
        """
        mtfs - list of motifs
        priors - dictionary of tuples, each tuple represents a prior over a transitions between states
            { 'g' : (9980, 20),
              'c'   : (66, 4),
              'p'   : (6, 2),
              'd'   : (1, 4, 1, 2)  / global, distal, clustal, proximal
            }            
        params - dictionary of parameters for the HMM
            bcg_k : k for the background markov model
            c_k   : k for the clustal markov model
            window : size of the window from which we'll estimate local emission probabilities
            r : number of clustal levels
        """        
        self.r = params.get('r', 1)     # by default use simple model
        self.priors = priors
        self.mtfs = mtfs
        self.nmtfs = len(mtfs)
        nmtfs = self.nmtfs
        self.nstates = sum([x.len for x in mtfs])*2 + nmtfs*2 + 1 + self.r
        self.a = zeros( (self.nstates, self.nstates), dtype='float' )
        self.mtf_block = [0] * nmtfs # index of the beginning of a motif block in a transition matrix
        self.mtf_block[0] = 1 + self.r + 4*nmtfs # b + c + N*d + N*p + 2*N*1st
        for i in range(1, nmtfs):
            self.mtf_block[i] = self.mtf_block[i-1] + 2*(mtfs[i-1].len-1)

        proximal_start = 1 + self.r
        distal_start = proximal_start + nmtfs
        mtf_start = distal_start + nmtfs
        self.start_motifs = mtf_start
        self.proximal_start = proximal_start
        self.distal_start = distal_start
        # initializing transition matrix
        a = self.a
        # background
        e = priors['g']
        e0 = sum(e)
        a[0, 0] = exp(psi(e[0]) - psi(e0))
        a[0, proximal_start:proximal_start+nmtfs] = (1-a[0,0]) / nmtfs
        # intra-cluster
        e = priors['c']
        e0 = sum(e)
        t = exp(psi(e[0]) - psi(e0))
        for i in range(1, 1+self.r):
            a[i, i] = t
            a[i, i+1] = t
        a[self.r, proximal_start:proximal_start+nmtfs] = (1-t) / nmtfs
        # proximal
        e = priors['p']
        e0 = sum(e)
        ep = exp(psi(e[0]) - psi(e0))
        eo = (1-ep) / 2
        for i in range(proximal_start, proximal_start+nmtfs):
            a[i, i] = ep
            a[i, i + 2 * nmtfs] = eo
            a[i, i + 3 * nmtfs] = eo
        # distal
        e = priors['d']
        e0 = sum(e)
        for i in range(distal_start, distal_start+nmtfs):
            a[i, 0] = exp(psi(e[0]) - psi(e0))
            a[i, i] = exp(psi(e[1]) - psi(e0))
            a[i, 1] = exp(psi(e[2]) - psi(e0)) # clustal
            t = (1 - a[i, 0] - a[i, i] - a[i, 1]) / nmtfs
            a[i, proximal_start:proximal_start+nmtfs] = t
        # other
        for i, m in zip(count(), mtfs):
            a[mtf_start + i, self.mtf_block[i]] = 1.
            a[mtf_start + i + nmtfs, self.mtf_block[i] + 1] = 1.
            for j in range(m.len-2):
                a[self.mtf_block[i]+2*j, self.mtf_block[i]+2*j+2] = 1.
                a[self.mtf_block[i]+2*j+1, self.mtf_block[i]+2*j+3] = 1.
            a[self.mtf_block[i]+2*m.len-4, distal_start + i] = 1.
            a[self.mtf_block[i]+2*m.len-3, distal_start + i] = 1.

        # parse parameters
        self.bcg_k = params.get("bcg_k", 2) # default is 2
        self.c_k = params.get("c_k", 2)  # default is 2
        self.window = params.get("window", 1600) # default is 1600
        
        self.b = [] # list of emission probabilities, each element of the list is an array
        self.alpha = []
        self.beta = []
        self.c = []
        self.seqs = []
    def init_params(self):
        from random import random

        nmtfs = self.nmtfs
        mtf_block = self.mtf_block
        start_motifs = self.start_motifs
        distal_start = self.distal_start
        proximal_start = self.proximal_start
        nstates = self.nstates
        a = self.a
        
        #background
        a[0, 0] = random()
        for i in range(proximal_start, proximal_start+nmtfs):
            a[0, i] = random()
        a[0, :] /= a[0, :].sum()
        #clustal
        a[1, 1] = random()
        a[1, 2] = random()
        a[1, :] /= a[1, :].sum()
        for i in range(1, self.r):
            a[1+i, 1+i] = a[1, 1]
            a[1+i, 2+i] = a[1, 2]            
        a[self.r, proximal_start:proximal_start+nmtfs] = a[1, 2] / nmtfs
        #proximal
        for i in range(proximal_start, proximal_start+nmtfs):
            a[i, i] = random()
            a[i, i + 2 * nmtfs] = random()
            a[i, i + 3 * nmtfs] = random()
            a[i, :] /= a[i, :].sum()
        #distal
        for i in range(distal_start, distal_start+nmtfs):
            a[i, i] = random()
            a[i, 0] = random()
            a[i, 1] = random()
            for j in range(proximal_start, proximal_start+nmtfs):
                a[i, j] = random()            
            a[i, :] /= a[i, :].sum()
    def save(self, f):
        """
        saves only variables needed for evaluation
        """
        from cPickle import dump
        try:
            f + ''
            f = open(f, 'w')
        except:
            pass
        f.write('%d\n' % self.nmtfs)
        f.write('%d\n' % self.nstates)
        f.write('%d\n' % self.start_motifs)
        f.write('%d\n' % self.proximal_start)
        f.write('%d\n' % self.distal_start)
        dump(self.mtf_block, f)
        
    def add_sequence(self, seq):
        self.seqs.append(seq.upper()) 
        self.b.append( zeros( (len(seq), self.nstates), dtype='float64' ) )
        self.alpha.append( zeros( (len(seq), self.nstates), dtype='float64' ) )
        self.beta.append( zeros( (len(seq), self.nstates), dtype='float64' ) )
        self.c.append( zeros( (len(seq),), dtype='float64' ) )
        
    def process(self):
        nmtfs = self.nmtfs
        bcg_model = BcgModel(self.bcg_k, 1)
        for seq in self.seqs:
            bcg_model.add_sequence( seq )
        
        for i, seq in zip(count(), self.seqs):
            b = self.b[i]
            prefix_bcg = ""
            prefix_c = ""
            local_model = BcgModel(self.c_k, 1)
            window_position = [0, self.window]
            local_model.add_sequence( seq, [window_position] )
            for si in range(len(seq)):
                nucl = seq[si]
                b[si, 0] = bcg_model.prob(nucl, prefix_bcg)
                # update local_model if necessary
                if si >= (window_position[1] - window_position[0]) / 2 and window_position[1] != len(seq) - 1:
                    local_model.update( seq[ window_position[0] ],
                                        seq[ max(0, window_position[0]-self.c_k):window_position[0] ],
                                        seq[ window_position[1]+1 ],
                                        seq[ window_position[1]-self.c_k+1:window_position[1]+1 ]
                                        )
                    window_position[0] += 1
                    window_position[1] += 1
                b[si, 1:self.start_motifs] = local_model.prob(nucl, prefix_c)
                for mi, m in zip(count(), self.mtfs):
                    b[si, self.start_motifs+mi] = m.site_prob(0, nucl, 0)
                    b[si, self.start_motifs+mi+nmtfs] = m.site_prob(0, nucl, 1)                    
                    for k in range(m.len-1):
                        b[si, self.mtf_block[mi]+2*k] = m.site_prob(k+1, nucl, 0)
                        b[si, self.mtf_block[mi]+2*k+1] = m.site_prob(k+1, nucl, 1)
                prefix_bcg = prefix_bcg + nucl
                prefix_bcg = prefix_bcg[-self.bcg_k:]
                prefix_c = prefix_c + nucl
                prefix_c = prefix_c[-self.c_k:]
    def forward(self):
        a = self.a
        mtfs = self.mtfs
        nmtfs = self.nmtfs
        mtf_block = self.mtf_block
        start_motifs = self.start_motifs
        distal_start = self.distal_start
        nstates = self.nstates
        
        for k in range(len(self.seqs)):
            b = self.b[k]
            alpha = self.alpha[k]
            c = self.c[k]
            t_alpha = zeros( (nstates,) )

            alpha[0, 0] = 1.
            c[0] = b[0, 0]
            for t in range(1, b.shape[0]):
                alpha[t, :] = dot(alpha[t-1, :], a)
                alpha[t, :] *= b[t, :]
                c[t] = sum(alpha[t, :])
                alpha[t, :] /= c[t]
    def backward(self):
        a = self.a
        mtfs = self.mtfs
        nmtfs = self.nmtfs
        mtf_block = self.mtf_block
        start_motifs = self.start_motifs
        distal_start = self.distal_start
        nstates = self.nstates

        for k in range(len(self.seqs)):
            b = self.b[k]
            beta = self.beta[k]
            c = self.c[k]

            beta[-1, :] = 1.
            for t in range(b.shape[0]-2, -1, -1):
                beta[t, :] = dot( a, b[t+1, :] * beta[t+1, :] )
                beta[t, :] /= c[t+1]        
    def em(self, **params):
        """
        params - dictionary
           max_iter : number of iterations of forward and backward procedures
           epsilon : minimal increase in likelihood
        """

        def _calculate_expected_count(expected_count, alpha, beta, a, b, c):
            expected_count[:, :] = 0
            th = c.reshape(-1, 1) * (b * beta) 
            for t in range(1, b.shape[0]):
                tmp = ( alpha[t-1, :].reshape(-1,1) * th[t, :] ) * a                
                tmp /= tmp.sum()
                expected_count += tmp
            
        max_iter = params.get("max_iter", 50)
        epsilon = params.get("epsilon", 1e-4)

        a = self.a
        priors = self.priors
        proximal_start = self.proximal_start
        distal_start = self.distal_start
        nmtfs = self.nmtfs
        nseqs = len(self.seqs)

        old_ll = -1e20
        old_a = self.a.copy()
        nstates = self.nstates
        expected_count = zeros( (nstates, nstates) )
        for iter in range(max_iter):
            print "Iteration: %d" % iter            
            self.forward()
            self.backward()
            ll = 0.
            for i in range(nseqs):
                ll += sum(log(self.c[i]))
            ll /= nseqs
            print "Likelihood %.9g" % ll 
            if abs(ll - old_ll) < epsilon: break # increase in ll minimal
            self.ll = ll
            old_ll = ll
            expected_count_avg = zeros( (nstates, nstates) )            
            for i in range(nseqs):
                _calculate_expected_count(expected_count, self.alpha[i], self.beta[i], a, self.b[i], self.c[i])
                expected_count_avg += expected_count
            expected_count_avg /= nseqs
            # background
            e = priors['g']            
            e0 = sum(e)
            ec0 = sum(expected_count_avg[0, :])
            a[0, 0] = exp(psi(e[0] + expected_count_avg[0, 0]) - psi(e0 + ec0))
            a[0, proximal_start:proximal_start+nmtfs] = exp(\
                 psi(expected_count_avg[0, proximal_start:proximal_start+nmtfs] + e[1] / nmtfs) - \
                 psi(e0 + ec0))
            # clustal
            e = priors['c']
            e0 = sum(e)
            exp_cnt = zeros((2,))
            for i in range(1, self.r+1):
                exp_cnt[0] += expected_count_avg[i, i]
                exp_cnt[1] += expected_count_avg[i, i+1:].sum()
            exp_cnt /= self.r
            ec0 = exp_cnt.sum()
            t = exp(psi(e[0] + exp_cnt[0]) - psi(e0 + ec0))
            for i in range(1, self.r+1):
                a[i, i] = t
                a[i, i+1] = 1 - t
            perc = expected_count_avg[self.r, proximal_start:proximal_start+nmtfs] / \
                   expected_count_avg[self.r, proximal_start:proximal_start+nmtfs].sum()
            a[self.r, proximal_start:proximal_start+nmtfs] = exp(\
                psi(perc * exp_cnt[1] + e[1] / nmtfs) - \
                psi(e0 + ec0))
            # proximal
            e = priors['p']
            e0 = sum(e)
            for i in range(proximal_start, proximal_start+nmtfs):
                ec0 = sum(expected_count_avg[i, :])
                a[i, i] = exp(psi(e[0] + expected_count_avg[i, i]) - psi(e0 + ec0))
                a[i, i + 2 * nmtfs] = exp(psi(e[0]/2 + expected_count_avg[i, i+2*nmtfs]) - psi(e0 + ec0))
                a[i, i + 3 * nmtfs] = exp(psi(e[0]/2 + expected_count_avg[i, i+3*nmtfs]) - psi(e0 + ec0))
            # distal - more parameters
            e = priors['d']
            e0 = sum(e)
            for i in range(distal_start, distal_start+nmtfs):
                ec0 = sum(expected_count_avg[i, :])
                a[i, 0] = exp(psi(e[0] + expected_count_avg[i, 0]) - psi(e0 + ec0))
                a[i, i] = exp(psi(e[1] + expected_count_avg[i, i]) - psi(e0 + ec0))
                a[i, 1] = exp(psi(e[2] + expected_count_avg[i, 1]) - psi(e0 + ec0)) # clustal
                a[i, proximal_start:proximal_start+nmtfs] = exp(\
                     psi(e[3]/nmtfs + expected_count_avg[i, proximal_start:proximal_start+nmtfs]) - \
                     psi(e0 + ec0))

def load(f):
    """
    loads only variables needed for evaluation
    """
    from cPickle import load
    try:
        f + ''
        f = open(f)
    except Exception, e:
        print e
    d = {}
    d['nmtfs'] = int(f.readline())
    d['nstates'] = int(f.readline())
    d['start_motifs'] = int(f.readline())
    d['proximal_start'] = int(f.readline())
    d['distal_start'] = int(f.readline())
    d['mtf_block'] = load(f)
    return d
    
    
