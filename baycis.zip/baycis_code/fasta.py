# loading fasta files
from itertools import count
from operator import itemgetter
from intervals import *

class MultiSequence(list):
    """Should store aligned sequences.

    Create after you have filled information in other sequences
    """

    def __init__(self, seqs):
        """
        :Parameters:
            seqs : list of Sequence objects
        """
        super(MultiSequence, self).__init__(seqs)
    def set_indicators(self, f):
        failed_to_load = []
        
        self.mtf_indicator = load_annotation(f, {'seq_containing_mtf' : len(self[0].mtf_type)})['seq_containing_mtf']

        try:
            self.mtf_type = self[0].mtf_type[:]
        except AttributeError:
            failed_to_load.append('mtf_type')
            
        try:
            self.mtf_position = self[0].mtf_position[:]
        except AttributeError:
            failed_to_load.append('mtf_position')
            
        try:
            self.mtf_direction = self[0].mtf_direction[:]
        except AttributeError:
            failed_to_load.append('mtf_direction')
            
        try:
            self.crm_border = self[0].crm_border[:]        
        except AttributeError:
            failed_to_load.append('crm_border')

        return failed_to_load

class Sequence(object):
    nucl_num = {'A':0, 'C':1, 'G':2, 'T':3}
    
    def __init__(self, name, seq):
        self.name = name
        self.seq = seq
        self.len = len(seq)
        self.attr = {}

    def write(self, f, chr_per_line=60):
        f.write(">%s\n" % self.name)
        len_seq = len(self.seq)
        for i in count():
            if i * chr_per_line > len_seq: break
            f.write("%s\n" % self.seq[i*chr_per_line:(i+1)*chr_per_line])

    def update_attributes(self, attr):
        self.__dict__.update(attr)

    def normalize_crm(self):
        """ Merge overlapping CRMs
        """
        crm_border = self.crm_border
        crms = [self.crm_border[0]]
        for c in crm_border[1:]:
            merge(crms, c)
        crms.sort(key=itemgetter(0))
        self.crm = crms

    def prob_mtf(self, position, mtf, forward=1):
        """Calculate probability of a motif in a sequence

        :Parameters:
            position : int
                       starting position of a motif
            mtf      : motif object
            forward  : Boolean
                       True - calculates a probability of a motif on a forward strand
                       False - calculates a probability of a motif on a bakcward strand
        :Returns:
            probability of a motif
        """
        prob = 1.0
        for i in range(mtf.len):
            prob *= (forward and [mtf.site_prob(i)] or [mtf.site_prob_back_strand(i)])[0][Sequence.nucl_num[self.seq[position+i]]]
        return prob

    def trim(self, size):
        """Helper function that keeps only first `size` numbers of nucleotides.
        """
        self.seq = self.seq[:size]
        self.len = size

    def crop(self, begin, end):
        """Helper function that keeps nucleotide [begin:end].
        """        
        self.seq = self.seq[begin:end]
        self.len = end - begin

    def __str__(self):
        return self.name + "::" + self.seq

def sequence_from_lines(lines):
    name = lines[0][1:].strip() # take everything except '>'
    seq = "".join([line.strip() for line in lines[1:]])
    return Sequence(name, seq)
    
def load_multi_fasta(f):
    """
    Load MULTI FASTA file.
    f is a file object or a file name    
    returns list of objects Sequence
    """ 
    try:
        f + ""
        f = open(f, 'r')
    except TypeError:
        pass   
    sequences = []
    begin = 1
    buffer = []
    for line in f:
        if line[0] == '>':
            if begin == 1:
                begin = 0
            else:
                sequences.append(sequence_from_lines(buffer))
                buffer = []
        buffer.append(line)
    if buffer:
        sequences.append(sequence_from_lines(buffer))

    return sequences

def load_fasta(f):
    return load_multi_fasta(f)[0]

#################################################################
###
### helper functions that load various information on fasta files
###
###

def load_annotation(f, extract):
    """ Load information about the sequence:
    :Parameters:
        f : file object or a valid file name
        extract : dictionary
                  key defines line you want to extract
                  value defines how many lines you want to read afterwards
    :Returns:
        dictionary
          key has name of extracted element
          value has extracted part
    """
    try:
        f + ""
        f = open(f, 'r')
    except TypeError:
        pass

    ret = {}
    for line in f:
        key = line.strip()
        if key in extract:
            element = []            
            for i in range(extract[key]):
                element.append(f.next().strip())
            ret[key] = element[:]
    return ret

def load_common_annotation(f):
    anno = load_annotation(f, {'mloc': 1,
                               'border': 1,
                               'type': 1,
                               'mtf_dir': 1})
    up = {}
    try:
        up["mtf_position"] = map(int, anno["mloc"][0].split(','))
    except KeyError:
        pass
    try:
        up["mtf_type"] = anno["type"][0].split(',')
    except KeyError:
        pass
    try:
        up["crm_border"] = [map(int, crm.split('-'))
                            for crm in anno["border"][0].split(',')]
    except KeyError:
        pass    
    try:
        up["mtf_direction"] =  anno["mtf_dir"][0].split(',')
    except KeyError:
        pass    
            
    return up
