"""
>>> nucl2num('a')
[0]
>>> nucl2num('c')
[1]
>>> nucl2num('-')
[0, 1, 2, 3]
>>> nucl2num('a-')
[0, 1, 2, 3]
>>> nucl2num('c-')
[4, 5, 6, 7]

"""

from combinations import create_combinations
import scipy as sc
import os
from itertools import count

order_nucl = ['A', 'C', 'G', 'T']

def nucl2num(seq):
    """
    Takes a sequence of nucleotides and return a list of numbers represented by the sequence. Sequences are
    represented as a number in a base(4). - stands for a gap. Each gap is expanded to represent multiple
    nucleotides.
    """
    sets = []
    for s in seq:
        if s == '-' or s == 'N':
            sets.append(order_nucl)
        else:
            sets.append([s])
    ret = []
    comb = (len(sets) >= 2) and create_combinations(*sets) or sets[0]
    for seq in comb:
        r = 0
        for i in seq:
            r = 4*r + order_nucl.index(i.upper())
        ret.append(r)
    return ret

def num2nucl(x):
    return order_nucl[x]

def leaf2num(l):
    """
    returns a list of numbers that correspond to this leaf

    TODO: only nucl_part can contain wild character at the moment
    """
    nucl_part = l[1]
    func_part = l[0]
    n = len(func_part)
    
    return [(1<<(2*n)) * int(func_part, 2) + nucl
            for nucl in nucl2num(nucl_part)]

def num2leaf(num, n):
    """
    TODO:  this doesn't work
    """
    nucl_part = num & ((1<<(2*n))-1)
    func_part = num >> (2*n)

    return func_part, nucl_part

def i2b(n, size=-1):
    hdigits = ('0000','0001','0010','0011','0100','0101','0110','0111',
               '1000','1001','1010','1011','1100','1101','1110','1111')
    
    a = [hdigits[int(d,16)] for d in hex(n)[2:]]
    ret = ''.join(a)
    if size < 1:
        return ret
    else:
        return ("".join(['0'] * size) + ret)[-size:]

def gap_in_seq(leaves, gap_mask):
    for l, m in zip(leaves, gap_mask):
        if l=='1' and m: return True
    return False

def count_nucleotides(seqs, skip_gap=True):
    ret = [0] * 4
    for seq in seqs:
        for i in range(4):
            ret[i] += seq.seq.count(order_nucl[i])
    return ret

##################
##  EVALUATION  ##
##################

def get_true_phylo_motifs(seq):
    true_type = []
    true_pos = []
    for t,p,ind in zip(seq.mtf_type, seq.mtf_position, seq.mtf_indicator):
        if ind[0] == '0': continue
        true_type.append(t)
        true_pos.append(p)

    return true_type, true_pos


def evaluate_motifs(pred, true, dist=3):
    """
    pred - list of tuples (type, position), represents list of prediction made by a programme
    true - list of tuples (type, position), represents list known motifs
    dist - distance between the true position and predicted one can be at most `dist`, i.e. abs(x1 - x2) <= dist
    """
    num_mtf = len(true)
    tp, fp = 0, 0
    flag = [0] * num_mtf
    for t,m in pred:
        found = False
        for i, (tt, tm) in zip(count(), true):
            if abs(tm-m)>dist: continue # too far from the validated motif site

            if t != tt: continue        # not the same type of motif

            if flag[i]:                 # this motif has already been marked as found; which means
                found = True            # that we predict two same motifs close to each other, so
                break                   # we doesn't count it as true positive or false positive

            tp += 1                     # mark motif as good
            flag[i] = 1
            found = True
            break
        if not found: fp += 1
    return tp, fp, num_mtf

def load_eval_points(a):
    """
    Each experimental point is given as an element in the list a. Each
    element of the list is a list, where first element represents directory
    and the other elements describe path to files with precision and recall.
    
    :Parameters:
        a - list
          - [[dir_1, file_1, file_2, ...],
             [dir_2: file_1, file_2, ...],
             ...
            ]
    :Returns:
        precision - 
        recall - 
    """
    num_points = len(a)
    precision = []
    recall = [] 
    for i, point in zip(count(), a):
        dir = point[0]
        pr, rc = [], []
        for file in point[1:]:
            try:
                t = open(os.path.join(dir, file)).readline().strip().split()
            except IOError, e:
                print e
                continue
            pr.append( float(t[0]) )
            rc.append( float(t[1]) )
        precision.append( pr )
        recall.append( rc )
    return precision, recall

def _test():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    _test()
