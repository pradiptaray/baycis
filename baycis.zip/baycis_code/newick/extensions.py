"""

>>> from tree import parse_tree
>>> from scipy import zeros, ones, array
>>> from combinations import create_combinations
>>> from models import ProbabilityMatrix, CombinedProbabilityMatrix
>>> from biotools import leaf2num
>>> t = parse_tree('((1:2,(2:1,3:1):1):1,4:3)')
>>> print t
(('1' : 2.0, ('2' : 1.0, '3' : 1.0) : 1.0) : 1.0, '4' : 3.0)
>>> rate_matrix = ones((4,4)) * .25
>>> for i in range(0,4): rate_matrix[i, i] = -0.75
>>> equi_freq = ones((4,)) * .25
>>> tran_matrix = ProbabilityMatrix(rate_matrix)
>>> pruner = Pruner(tran_matrix)
>>> s1 = set(['A', 'C', 'G', 'T'])
>>> prob = 0.0
>>> for c in create_combinations(*([s1]*4)):
...     pruner.set_leaves(c)
...     t.dfs_traverse(pruner)
...     assert len(pruner.stack) == 1
...     prob += pruner.likelihood(equi_freq)
...
>>> print prob
1.0

>>> func_matrix = array([[-.5,.5],[.5,-.5]])
>>> tran_matrix = CombinedProbabilityMatrix(rate_matrix, rate_matrix, func_matrix)
>>> pruner = Pruner(tran_matrix, num_chr=8, chr2num=leaf2num)
>>> s2 = set(['0', '1'])
>>> prob = 0.0
>>> for c in create_combinations(*([s1]*4)):
...     for f in create_combinations(*([s2]*4)):
...         pruner.set_leaves(zip(f, c))
...         t.dfs_traverse(pruner)
...         assert len(pruner.stack) == 1
...         prob += pruner.likelihood(equi_freq, 0)
...         assert pruner.likelihood(equi_freq, 0) == tree_likelihood(t, equi_freq)
...
>>> print prob
1.0
>>> prob = 0.0
>>> for c in create_combinations(*([s1]*4)):
...     for f in create_combinations(*([s2]*4)):
...         pruner.set_leaves(zip(f, c))
...         t.dfs_traverse(pruner)
...         assert len(pruner.stack) == 1
...         prob += pruner.likelihood(equi_freq, 1)
...
>>> print prob
1.0

"""


from tree import TreeVisitor, parse_tree
from models import ProbabilityMatrix, CombinedProbabilityMatrix
from biotools import nucl2num, num2nucl
from scipy import zeros, ones, dot, array, random

def copy(tree):
    """
    Copies only topology and branch lengths.
    """
    return parse_tree(str(tree).replace("'","").replace(" ", ""))

def scale_tree(tree, scale_factor):
    '''Multiply each edge with the scale_factor'''
    class V(TreeVisitor):
        def __init__(self, scale_factor):
            self.scale_factor = scale_factor
        def pre_visit_tree(self,t):
            _edges = []
            for (n,b,l) in t._edges:
                _edges.append((n,b,l*self.scale_factor))
            t._edges = _edges
    tree.dfs_traverse(V(scale_factor))

def evolve_nucl(tree, nucl, prob, chr2num=nucl2num, num2chr=num2nucl):
    '''Evolve a nucleotide along the tree. Starting nucleotide is nucl. Probability distribution is given by prob'''
    class V(TreeVisitor):
        def __init__(self, prob):
            self.prob = prob
        def pre_visit_edge(self, src, b, l, dst):
            dst.nucl = num2chr(random.multinomial(1, self.prob.P(l)[chr2num(src.nucl)[0], :]).argmax())
    tree.nucl = nucl
    tree.dfs_traverse(V(prob))
    ret = ""
    for l in tree.get_leaves():
        ret += l.nucl
    return ret

## def tree_likelihood(tree, equi_freq, func_cat=0, markov_order=1):
##     return (tree.p_d[func_cat*(1<<(2*markov_order)):(func_cat+1)*(1<<(2*markov_order))] * equi_freq).sum()           

## class Pruner(TreeVisitor):
##     '''
##     Felsenstein pruning tree algorithm

##     *  implements message passing towards the root of the tree
##     *  probabilities are stored in node.p_d
##     '''  
        
##     def visit_leaf(self, l):
##         from scipy import r_
##         if self.cur_pos == self.cur_max:
##             t = zeros((1, self.num_chr), dtype=float)
##             self.stack = r_[self.stack, t]
##             self.cur_max += 1
##         # check if the leaf is `*`
##         # chr2num should return list of numbers
##         if self.gaps[self.current_leaf]:
##             self.stack[self.cur_pos, :] = 1.
##         else:            
##             self.stack[self.cur_pos, self.chr2num(self.leaves[self.current_leaf])] = 1.
##         self.cur_pos += 1
##         self.current_leaf += 1
        
##     def post_visit_edge(self,src,bootstrap,length,dst):
##         self.stack[self.cur_pos-1, :] = dot(self.tran.P(length),
##                                             self.stack[self.cur_pos-1, :])

##     def post_visit_tree(self, tree):
##         num_children = len(tree._edges)
##         self.stack[self.cur_pos-num_children] = \
##                                               self.stack[self.cur_pos-num_children:self.cur_pos, :].prod(0)
##         self.cur_pos = self.cur_pos - num_children + 1
        
##     def likelihood(self, equi_freq, func_cat=0):
##         return (self.stack[0, func_cat*(1<<(2*self.markov_order)):(func_cat+1)*(1<<(2*self.markov_order))] * equi_freq).sum()

            
def _test():        
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    _test()
