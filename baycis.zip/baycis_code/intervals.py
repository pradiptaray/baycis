from itertools import count

def within(inter, p):
    return p >= inter[0] and p < inter[1]
        
def merge(inters, a):
    """
    inters - colection of intervals
    a - interval to be merged with intervals

    Merge intervals if one endpoint is contained within the other one.
    """
    b = -1
    e = -1
    for i,inter in zip(count(), inters):
        if within(inter, a[0]): b = i
        if within(inter, a[1]): e = i
    if b == -1 and e == -1:
        inters.append(a)
    elif b == -1 and e != -1:
        m = inters.pop(e)
        m[0] = a[0]
        inters.append(m)
    elif b != -1 and e == -1:
        m = inters.pop(b)
        m[1] = a[1]
        inters.append(m)
    else:
        pass
