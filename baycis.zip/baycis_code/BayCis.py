#!/usr/bin/python

import sys
from ConfigParser import ConfigParser, NoOptionError
import fasta, mtf
from hmm import HMM
from scipy import array
from scipy.io import numpyio, write_array
import os.path

params = sys.argv[1]

config = ConfigParser()
config.read([params])

out_dir = config.get("DEFAULT", "out_dir")
config_name = config.get("DEFAULT", "config_name")

#############
# load priors

priors = {}
t = config.getfloat("Hyper-params", "wg")
priors['g'] = array([1-t, t]) * config.getfloat("Hyper-params", "Ng")

t = config.getfloat("Hyper-params", "wc")
priors['c'] = array([1-t, t]) * config.getfloat("Hyper-params", "Nc")

t = config.getfloat("Hyper-params", "wp")
priors['p'] = array([1-t, t]) * config.getfloat("Hyper-params", "Np")

t = [config.getfloat("Hyper-params", "wd1"),
     config.getfloat("Hyper-params", "wd2"),
     config.getfloat("Hyper-params", "wd3")]
priors['d'] = array([t[0], 1-sum(t), t[1], t[2]]) * config.getfloat("Hyper-params", "Nd")

######################
# load hmmm parameters

params = {}
params['bcg_k'] = config.getint("Params", "bcg_k")
params['c_k'] = config.getint("Params", "c_k")
params['window'] = config.getint("Params", "window")
params['r'] = config.getint("Params", "r")

max_iter = config.getint("Params", "max_iter")
epsilon = config.getfloat("Params", "epsilon")
num_restarts = config.getint("Params", "num_restarts")

#############
# load motifs

mtf_dir = config.get("DEFAULT", "mtf_dir")
num_mtfs = config.getint("Motifs", "num_mtfs")
mtfs = []
for i in range(num_mtfs):
    tmp = eval(config.get("Motifs", str(i)))
    fname = "%s/%s" % (mtf_dir, tmp[1])
    m = mtf.load_ACGT( tmp[0], fname )
    m.init_prob()
    mtfs.append( m )

################
# create HMM

h = HMM( mtfs, priors, params )
h.save(config.get("Eval", "hmm"))

####################################
# load sequences and add them to HMM

num_seq = config.getint("Sequences", "num_seq")
seq_dir = config.get("DEFAULT", "seq_dir")
for i in range(num_seq):
    seq_name = config.get("Sequences", str(i))
    seq_fname = os.path.join(seq_dir, seq_name)
    seq = fasta.load_fasta( seq_fname )
    
    h.add_sequence( seq.seq )

# precalculate emission probabilities
h.process()

old_ll = -1e100
for it in range(num_restarts):
    print "Starting EM %d" % it
    h.init_params()
    h.em(max_iter=max_iter, epsilon=epsilon)
    
    if h.ll > old_ll:
        old_ll = h.ll
        for i in range(num_seq):
            t = h.alpha[i] * h.beta[i]

            out_fname = config.get("Eval", "post", vars={'config_name': '%s_seq_%d' % (config_name, i)})
            numpyio.fwrite( open(out_fname, 'wb'), t.size, t )
            out_fname = config.get("Eval", "params", vars={'config_name': '%s_seq_%d' % (config_name, i)})
            f = open(out_fname, 'wt')
            f.write("%s\n%s\n%s\n" % (repr(t.dtype),
                                      repr(t.size),
                                      repr(t.shape)))
            f.close()

            write_array(config.get("Eval", "a"),
                        h.a[0:h.start_motifs, 0:h.mtf_block[0]], separator=' ', linesep='\n')

