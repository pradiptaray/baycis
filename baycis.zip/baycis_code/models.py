"""

>>> from models import BcgModel
>>> a = BcgModel(0)
>>> a.add_sequence("a")
>>> print a.freq("a")
1
>>> print a.freq("c")
0
>>> print a.update("a", "", "c", "")
0
>>> print a.freq("a")
0
>>> print a.freq("c")
1

>>> a = BcgModel(1)
>>> a.add_sequence("acga")
>>> print a.freq("a")
5
>>> print a.freq("a", "g")
2
>>> print a.freq("a", "t")
1
>>> print a.freq("c")
1
>>> print a.freq("c", "g")
0
>>> print a.freq("c", "ga")
1
>>> print a.update("c", "a", "t", "a")
0
>>> print a.freq("c")
0
>>> print a.freq("t")
1
>>> print a.freq("t", "a")
1
>>> print a.update("t", "a", "c", "a")
0
>>> a.add_sequence("ttaccgact")
>>> print a.freq("t", "t")
2
>>> print a.freq("c", "ac")
1
>>> print a.freq("c", "aa")
3

>>> a = BcgModel(0)
>>> a.add_sequence("acga", [(0,1), (3,4)])
>>> print a.freq("a")
2

>>> a = BcgModel(1)
>>> a.add_sequence("acga", [(0,1), (2,4)])
>>> print a.freq("a", "g")
2
>>> print a.freq("c")
0

>>> a = BcgModel(0)
>>> a.add_sequence("acga")
>>> print a.prob("a")
0.375

>>> a = BcgModel(0, 0)
>>> a.add_sequence("acga")
>>> print a.prob("a")
0.5

>>> a = BcgModel(1, 0)
>>> a.add_sequence("acga")
>>> print a.prob("a")
0.75

>>> a = BcgModel(1)
>>> a.add_sequence("acga")
>>> print abs(a.prob("a") - 0.39166666666666666) < 1e-10
True
>>> print a.update("a", "", "t", "a")
0
>>> print a.freq("a")
1
>>> print a.freq("t", "a")
1
>>> print a.freq("t", "c")
0
>>> print a.update("c", "a", "g", "t")
0
>>> print a.freq("g", "")
2
>>> print a.freq("g", "t")
1

>>> a = BcgModel(2)
>>> a.add_sequence("acga")
>>> print a.freq("a")
17
>>> print a.freq("a", "g")
5
>>> all( (a.f.sum(1) + a.pseudo_count * 4) == a.sf)
True
>>> print a.update("a", "", "c", "ga")
0
>>> print a.freq("c")
5
>>> print a.freq("c", "ga")
2
>>> print a.update("c", "a", "t", "ac")
0
>>> print a.freq("g")
1
>>> print a.freq("t")
1
>>> print a.freq("t", "gc")
0
>>> print a.freq("t", "c")
1
>>> print a.freq("t", "a")
0
>>> all( (a.f.sum(1) + a.pseudo_count * 4) == a.sf)
True
>>> print a.update("g", "ac", "g", "ct")
0
>>> print a.freq("g")
1
>>> print a.freq("g", "ct")
1
>>> print a.freq("a")
1
>>> all( (a.f.sum(1) + a.pseudo_count * 4) == a.sf)
True

"""

from scipy import array, zeros, arange, tile, ones, random
from scipy.io.numpyio import fwrite, fread
from biotools import nucl2num, num2nucl, order_nucl
import struct
from combinations import create_combinations
from itertools import count
from newick.tree import Leaf

#TODO: add gaps
class BcgModel(object):
    """
    kth order markov model for the sequence
    """
    def __init__(self, k=0, pseudo_count=1):
        """
        k - kth markov order background
        pseudo_count - number added to each bin of frequencies
              when calculating probabilities, it does not have
              and influence on the return values from `freq`
              function
        """
        self.k = k
        self.f = zeros( (max(4**k, 1), 4), dtype=int)
        self.sf = ones( (max(4**k, 1), ), dtype=float) * 4 * pseudo_count
        self.pseudo_count = pseudo_count
    def save(self, f):
        f.write(struct.pack('i', self.k))
        f.write(struct.pack('f', self.pseudo_count))
        fwrite(f, self.f.size, self.f)
        fwrite(f, self.sf.size, self.sf)
    @classmethod
    def load(cls, f):        
        k = struct.unpack( 'i', f.read(struct.calcsize('i')) )[0]
        pseudo_count = struct.unpack( 'f', f.read(struct.calcsize('f')) )[0]

        bcg_model = cls(k, pseudo_count)
        bcg_model.f = fread(f, max(4**k, 1) * 4, 'i')
        bcg_model.f = bcg_model.f.reshape( (max(4**k, 1), 4) )
        bcg_model.sf = fread(f, max(4**k, 1), 'd')
        return bcg_model
    @classmethod
    def load_from_list(cls, lst):
        from scipy import log
        bcg_model = cls(k=int(log(len(lst))/log(4))-1, pseudo_count=0)
        it = reversed(lst)
        for i in range(len(lst)/4):
            for j in range(4):
                bcg_model.f[i, j] = int(it.next() * 100)
        bcg_model.sf = bcg_model.f.sum(1).astype(float)
        return bcg_model    
    def add_sequence(self, seq, intervals=[]):
        """
        seq - Sequence object
        intervals - learn only from a subset of the sequence        
        """
        k = self.k
        freq = self.f
        sf = self.sf
        length = len(seq)
        
        intervals = intervals or [(0, length)]
        for interval in intervals:
            b = max(interval[0], 0)
            e = min(interval[1], length)
            prefix = 0
            i = b
            lp = 0
            while i != e:
                nucl = nucl2num(seq[i])
                if len(nucl) > 1:
                    continue
                else:
                    nucl = nucl[0]
                if k==0:
                    freq[0, nucl] += 1
                    sf[0] += 1
                    i+=1
                    continue
                if lp==0:
                    freq[:, nucl] += 1
                    sf[:] += 1
                elif lp < k:
                    index = (arange(0, 4**k) % 4**lp).T == prefix
                    freq[index, nucl] += 1
                    sf[index] += 1
                else:
                    freq[prefix, nucl] += 1
                    sf[prefix] += 1
                prefix = 4*prefix + nucl
                if lp == k:
                    prefix %= 4**k
                else:
                    lp += 1
                i += 1
    def freq(self, nucl, prefix = ""):
        """
        Assumptions:
          len(nucl) == 1
          nucl and prefix do not contain gaps
        """
        if self.k == 0:
            return self.f[0, nucl2num(nucl)[0]]
        elif len(prefix) == 0:
            return self.f[:, nucl2num(nucl)[0]].sum()
        elif len(prefix) >= self.k:
            return self.f[nucl2num(prefix)[0] % 4**self.k, nucl2num(nucl)[0]]
        else:
            return self.f[(arange(0, 4**self.k) % 4**len(prefix)).T==nucl2num(prefix)[0],
                          nucl2num(nucl)[0]].sum()
        
    def update(self, nucl_remove, prefix_remove, nucl, prefix):
        """
        Assumptions:
          no gaps
        """
        if self.k == 0:
            self.f[0, nucl2num(nucl_remove)[0]] -= 1
            self.sf[0] -= 1
        elif len(prefix_remove) == 0:
            self.f[:, nucl2num(nucl_remove)[0]] -= 1
            self.sf[:] -= 1
        elif len(prefix_remove) >= self.k:
            index = nucl2num(prefix_remove)[0] % 4**self.k
            self.f[index, nucl2num(nucl_remove)[0]] -= 1
            self.sf[index] -= 1
        else:
            index = (arange(0, 4**self.k) % 4**len(prefix_remove)).T==nucl2num(prefix_remove)[0]
            self.f[index, nucl2num(nucl_remove)[0]] -= 1
            self.sf[index] -= 1

        if self.k == 0:
            self.f[0, nucl2num(nucl)[0]] += 1
            self.sf[0] += 1
        elif len(prefix) == 0:
            self.f[:, nucl2num(nucl)[0]] += 1
            self.sf[:] += 1
        elif len(prefix) >= self.k:
            index = nucl2num(prefix)[0] % 4**self.k
            self.f[index, nucl2num(nucl)[0]] += 1
            self.sf[index] += 1
        else:
            index = (arange(0, 4**self.k) % 4**len(prefix)).T==nucl2num(prefix)[0]
            self.f[index, nucl2num(nucl)[0]] += 1
            self.sf[index] += 1
        return 0
        
    def prob(self, nucl, prefix = ""):
        if self.k == 0:
            return (self.f[0, nucl2num(nucl)[0]] + self.pseudo_count) / self.sf[0]
        elif len(prefix) == 0:
            return ((self.f[:, nucl2num(nucl)[0]] + self.pseudo_count) / self.sf).sum() / self.f.shape[0]
        elif len(prefix) >= self.k:
            index = nucl2num(prefix)[0] % 4**self.k
            return (self.f[index, nucl2num(nucl)[0]] + self.pseudo_count) / self.sf[index]
        else:
            index = (arange(0, 4**self.k) % 4**len(prefix)).T==nucl2num(prefix)[0]
            return ((self.f[index, nucl2num(nucl)[0]] + self.pseudo_count) / self.sf[index]).sum() / sum(index)
    def generate(self, prefix = ""):
        p = [0] * 4
        for i in range(4):
            p[i] = self.prob(num2nucl(i)[0], prefix)
        return num2nucl( random.multinomial(1, p).argmax() )
    def generate_seq(self, n):
        ret = ""
        for i in range(n):
            ret += self.generate(ret[-self.k:0])
        return ret

## def HKY(nucl, k):
##     """
##     returns the rate matrix for HKY model based
##     on equlibrium frequencies and K
##     """
##     rate = zeros((4,4), dtype=float)
##     for i in range(4):
##         rate[i, :] = nucl
##         rate[i, i] = 0.0
##     rate[0, 2] *= k
##     rate[1, 3] *= k
##     rate[2, 0] *= k
##     rate[3, 1] *= k
    
## #    rate /= rate.sum()
    
##     for i in range(4):
##         rate[i, i] = -rate[i, :].sum()
##     return rate

def F84(nucl, k):
    """
    returns the rate matrix for F84 model based
    on equlibrium frequencies and K
    """
    pi_y = nucl[1] + nucl[3]
    pi_r = nucl[0] + nucl[2]
    rate = zeros((4,4), dtype=float)
    for i in range(4):
        rate[i, :] = nucl
        rate[i, i] = 0.0
    rate[0, 2] *= (1+k/pi_r)
    rate[1, 3] *= (1+k/pi_y)
    rate[2, 0] *= (1+k/pi_r)
    rate[3, 1] *= (1+k/pi_y)

    rate /= 4*nucl[3]*nucl[1]*(1+k/pi_y) + 4*nucl[0]*nucl[3]*(1+k/pi_r) + 4*pi_y*pi_r    
    for i in range(4):
        rate[i, i] = -rate[i, :].sum()
    return rate

def F81_anno(nucl):
    a = 0.5 / nucl[0]
    b = 0.5 / nucl[1]
    rate = array([[-a, a],
                  [b, -b]], dtype=float)
##     rate = array([[-nucl[1], nucl[1]],
##                   [nucl[0], -nucl[0]]], dtype=float)
    
    return rate
    

class ProbabilityMatrix(object):
    def __init__(self, rate_matrix):
        from scipy.linalg import eig, inv        
        from numpy import real
        while True:
            try:
                (self.w, self.vl) = eig(rate_matrix)
                self.w = real(self.w)
                self.vl = real(self.vl)
                self.vr = inv(self.vl)
                break
            except:
                for i in range(rate_matrix.shape[0]):
                    for j in range(rate_matrix.shape[1]):
                        rate_matrix[i,j] += random.normal(0, 0.00001)
        self._P_cache = {}
        
    def P(self, t):
        from scipy import dot, exp
        try:
            tmp = self._P_cache[t]
        except KeyError:
            tmp = dot(self.vl * exp(self.w * t), self.vr)
            tmp = (tmp.T / tmp.sum(1)).T
            self._P_cache[t] = tmp.copy()
        return tmp
    def Pprime(self, t, r):
        from scipy import dot, exp
        tmp = dot(self.vl * (self.w * t) * exp(self.w * t * r), self.vr)
        return tmp

class CombinedProbabilityMatrix(object):
    def __init__(self, rm_bkg, rm_mtf, rm_func):
        from scipy.linalg import eigh
        
        (self.w_bkg, self.vl_bkg) = eigh(rm_bkg)
        self.vr_bkg = array(self.vl_bkg.T)
        (self.w_mtf, self.vl_mtf) = eigh(rm_mtf)
        self.vr_mtf = array(self.vl_mtf.T)        
        (self.w_func, self.vl_func) = eigh(rm_func)
        self.vr_func = array(self.vl_func.T)

    def P(self, t):
        from scipy import dot, exp, r_, c_

        # nucleotide substitution probability
        # bkg
        p_bkg = dot(self.vl_bkg * exp(self.w_bkg * t), self.vr_bkg)
        # mtf
        p_mtf = dot(self.vl_mtf * exp(self.w_mtf * t), self.vr_mtf)
        # functional substitution
        p_func = dot(self.vl_func * exp(self.w_func * t), self.vr_func)

        ret = zeros((p_bkg.shape[0]*2, p_bkg.shape[1]*2))
        return r_[
            c_[p_bkg*p_func[0,0], p_mtf*p_func[0,1]],
            c_[p_bkg*p_func[1,0], p_mtf*p_func[1,1]]
            ]

def _add_transition_probabilities(tree, tran, scaling_factor, attr_name='transitions'):
    if isinstance(tree, Leaf): return            
    setattr(tree, attr_name, [])
    for ord, (dst, _, l) in zip(count(), tree._edges):
        getattr(tree, attr_name).append(tran.P(l*scaling_factor))
        dst.order_child = ord
        _add_transition_probabilities(dst, tran, scaling_factor)

def _set_messages(tree):
    if isinstance(tree, Leaf): return
    tree.messages = []
    for (dst, _, _) in tree._edges:
        _set_messages(dst)        

class PhyloTree(object):                
    def __init__(self, tree, tran, equi, chr2num=nucl2num):        
        from newick.extensions import copy as tree_copy
        from newick.tree import add_parent_links
        from copy import copy
                
        self._scaling_factor = 1.                
        self.tree = tree_copy(tree)
        add_parent_links(self.tree)
        
        self.tran = copy(tran)
        self.equi = equi.copy()

        self.num_chr = equi.size
        self.chr2num = chr2num

    def set_leaves(self, leaves, gaps=[]):
        _set_messages(self.tree)
        self.leaves = leaves
        self.gaps = gaps or ([0] * len(leaves))

    def set_scaling_factor(self, r):
        from newick.extensions import scale_tree
        self._scaling_factor = r
        _add_transition_probabilities(self.tree, self.tran, self._scaling_factor)
    def get_scaling_factor(self):
        return self._scaling_factor
    scaling_factor = property(get_scaling_factor, set_scaling_factor)

    def up_pass(self):
        from numpy import prod, dot
        q = self.tree.get_leaves()[:]
        for i, leaf in zip(count(), q):
            if self.gaps[i]:
                leaf.p_d = ones((self.num_chr,))
            else:
                leaf.p_d = zeros((self.num_chr,))
                leaf.p_d[self.chr2num(self.leaves[i])] = 1.
        while q:
            t = q.pop(0)
            try:
                par = t.parent
            except AttributeError:
                break
            
            num_children = len(par._edges)
            par.messages.append(dot(par.transitions[t.order_child], t.p_d))
            if len(par.messages) == num_children:
                par.p_d = prod(par.messages, axis=0)
                q.append(par)
                
    def down_pass(self):
        from numpy import prod, dot
        tran = self.tran
        t = self.tree
        ll = self.likelihood()
        t.p_u = self.equi.copy()
        t.p = t.p_d * self.equi / ll;
        q = [t]
        while q:
            t = q.pop(0)
            if isinstance(t, Leaf): continue
            edges = t._edges

            for i in range(len(edges)):
                # \sum_b p(a|b,\beta_u) * p(\bar L_t, t=b) * p_b
                message = t.messages.pop(i)
                tmp_prod = prod(t.messages, axis=0) * t.p_u
                t.messages.insert(i, message)
                u = edges[i][0]                

                u.p_u = dot(message, tmp_prod)
                u.p = u.p_u * u.p_d / ll
                u.suff_stat = ((t.transitions[i] * u.p_d).T * (t.p / message)).T
                
    def likelihood(self):
        from numpy import dot
        return dot(self.tree.p_d, self.equi)

class CombinedPhyloTree(object):
    def __init__(self, tree, mtf_tran, bkg_tran, mtf_equi, bkg_equi):        
        from newick.extensions import copy as tree_copy
        from newick.tree import add_parent_links
        from copy import copy
        
        self.scaling_factor = [1., 1.]
        self.tree = tree_copy(tree)
        self.tran = [copy(bkg_tran), copy(mtf_tran)]
        self.equi = [bkg_equi.copy(), mtf_equi.copy()]
        add_parent_links(self.tree)

        self.num_chr = 4
        self.chr2num = nucl2num
        
    def set_anno_tree(self, anno_tree):
        self.anno_tree = anno_tree

    def set_leaves(self, leaves):
        _set_messages(self.tree)
        self.leaves = leaves
        
    def set_scaling_factor(self, r, mtf=0):
        from newick.extensions import scale_tree
        self.scaling_factor[int(mtf)] = r
        _add_transition_probabilities(self.tree, self.tran[int(mtf)], r, attr_name='transitions_%d' % int(mtf))
                                
    def up_pass(self):
        from numpy import prod, dot
        q = zip(self.tree.get_leaves()[:],
                self.anno_tree.get_leaves()[:])
        for i, (leaf, _) in zip(count(), q):
            leaf.p_d = zeros((self.num_chr,))
            leaf.p_d[self.chr2num(self.leaves[i])] = 1.            
        while q:
            (t, anno_t) = q.pop(0)
            try:
                par = t.parent
                anno_par = anno_t.par
            except AttributeError:
                break
            
            num_children = len(par._edges)
            par.messages.append(dot(getattr(par.transitions, 'transitions_%d' % anno_t.map_nucl)[t.order_child],
                                    t.p_d))
            if len(par.messages) == num_children:
                par.p_d = prod(par.messages, axis=0)
                q.append((par, anno_par))
    
    def likelihood(self):
        from numpy import dot
        return dot(self.tree.p_d, self.phylo_tree[self.anno_tree.map_nucl].equi)
        
def _test():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    _test()
