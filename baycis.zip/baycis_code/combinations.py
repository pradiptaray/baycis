
def create_combinations(*sets):
   if not sets: return []
   F = MakeListComprehensionFunction ('F', len(sets))
   return F(*sets)

def MakeListComprehensionFunction (name, nsets):
   """Returns a function applicable to exactly <nsets> sets.
      The returned function has the signature
         F(set0, set1, ..., set<nsets>)
      and returns a list of all element combinations as tuples.
      A set may be any iterable object.
   """
   if nsets <= 0:
      source = 'def %s(): return []\n' % name
   else:
      constructs = [ ('set%d'%i, 'e%d'%i, 'for e%d in set%d'%(i,i))
                     for i in range(nsets) ]
##       constructs = [ ('list%d'%i, 'e%d'%i, 'for e%d in list%d'%(i,i))
##                      for i in range(nsets) ]      
      a, e, f = map(None, *constructs)
      ##e.reverse() # <- reverse ordering of tuple elements if needed
      source = 'def %s%s:\n   return [%s %s]\n' % \
               (name, _tuplestr(a), _tuplestr(e), ' '.join(f))
   scope = {}
   exec source in scope
   return scope[name]

def _tuplestr(t):
   if not t: return '()'
   return '(' + ','.join(t) + ',)'
